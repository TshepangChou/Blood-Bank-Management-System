package blood.bank.management.system;

public class BloodBankManagementSystem 
{
    public static void main(String[] args) 
    {
    }   
}